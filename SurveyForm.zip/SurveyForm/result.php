<h5>Submited Information</h5>
	Name:  <?php echo $_POST['name'];     ?>

<form action="info.php">
	<input type="submit" name="ss" value="Go Back">
</form>